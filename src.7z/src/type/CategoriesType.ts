export type CategoriesType = {
  [tag: string]: {
    title: string;
    color: string;
    expense: boolean;
  };
};
