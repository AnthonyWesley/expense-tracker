export type ItemType = {
  id: string;
  date: Date;
  category: string;
  title: string;
  value: number;
};
