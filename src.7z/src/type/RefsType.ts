export type RefsType = {
  titleRef: React.MutableRefObject<HTMLInputElement | null>;
  valueRef: React.MutableRefObject<HTMLInputElement | null>;
  categoryRef: React.MutableRefObject<HTMLInputElement | null>;
  dateRef: React.MutableRefObject<HTMLInputElement | null>;
};
