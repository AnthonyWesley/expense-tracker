import { ItemType } from "@/type/ItemType";

export const items: ItemType[] = [
  {
    id: 0,
    date: new Date(2023, 9, 1),
    category: "salary",
    title: "bonus joob",
    value: 500.0,
  },
  {
    id: 1,
    date: new Date(2023, 9, 5),
    category: "salary",
    title: "bonus joob",
    value: 900.0,
  },
  {
    id: 2,
    date: new Date(2023, 9, 31),
    category: "food",
    title: "McDonalds",
    value: 25.1,
  },
  {
    id: 3,
    date: new Date(2023, 9, 25),
    category: "clothing",
    title: "Zara",
    value: 79.99,
  },
  {
    id: 4,
    date: new Date(2023, 9, 15),
    category: "entertainment",
    title: "Movie Theater",
    value: 12.5,
  },

  {
    id: 5,
    date: new Date(2023, 9, 6),
    category: "salary",
    title: "bonus joob",
    value: 900.0,
  },
  {
    id: 6,
    date: new Date(2023, 9, 27),
    category: "groceries",
    title: "Grocery Store",
    value: 45.75,
  },
  {
    id: 7,
    date: new Date(2023, 9, 5),
    category: "electronics",
    title: "Apple Store",
    value: 500.0,
  },

  {
    id: 8,
    date: new Date(2023, 9, 14),
    category: "salary",
    title: "bonus joob",
    value: 900.0,
  },
  {
    id: 9,
    date: new Date(2023, 9, 19),
    category: "transportation",
    title: "Gas Station",
    value: 35.5,
  },
];
