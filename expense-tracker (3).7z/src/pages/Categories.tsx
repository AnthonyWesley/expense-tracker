import React, { useState } from "react";
import G_InputArea from "../components/generics/G_InputArea";
import G_Select from "../components/generics/G_Select";
import G_Button from "../components/generics/G_Button";

import { useApiContext } from "../context/ApiContext";
import { CategoryApiType } from "../type/CategoryType";
import { ErrorObject, Toast } from "../components/generics/Toast";
import EditedInput from "../components/generics/EditedInput";
import { useNavigate } from "react-router-dom";
import { Icon } from "@iconify/react/dist/iconify.js";
import { G_Alert } from "../components/generics/G_Alert";

const tableColors = [
  "#0f172a", // slate-900
  "#64748b", // slate
  "#6b7280", // gray
  "#71717a", // zinc
  "#f97316", // orange
  "#f59e0b", // amber
  "#eab308", // yellow
  "#84cc16", // lime
  "#22c55e", // green
  "#10b981", // emerald
  "#14b8a6", // teal
  "#06b6d4", // cyan
  "#0ea5e9", // sky
  "#3b82f6", // blue
  "#2c3e50", // Midnight Blue
  "#6366f1", // indigo
  "#6f42c1", // Deep Purple
  "#8b5cf6", // violet
  "#a855f7", // purple
  "#d946ef", // fuschia
  "#ec4899", // pink
  "#cf6a87", // Pale Pink
  "#f43f5e", // rose
  "#ef4444", // red
  "#c0392b", // Indian Red
];

const status = ["RECEITAS", "DESPESAS"];
const Categories: React.FC = () => {
  const [newCategory, setNewCategory] = useState<CategoryApiType>({
    title: "",
    color: "",
    expense: false,
  });

  const {
    categories,
    apiCreateCategory,
    apiDeleteCategory,
    apiUpdateCategory,
    apiUpdateMany,
  } = useApiContext();

  // const [isAlertOpen, setIsAlertOpen] = useState(false);
  const categoriesArray = Object.values(categories);
  const [errors, setErrors] = useState();

  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewCategory((event) => ({ ...event, title: e.target.value }));
  };

  const handleCreate = () => {
    if (!newCategory.title || !newCategory.color) {
      setErrors({ error: "Preencha todas os campos!" });

      return;
    }
    if (
      categoriesArray
        .filter((cat) => cat.title)
        .map((item) => item.title)
        .includes(newCategory.title.toUpperCase().trim())
    ) {
      setErrors({
        error: `${newCategory.title} já existe. Escolha outro nome!`,
      });
    } else {
      apiCreateCategory(newCategory);
      setNewCategory({
        title: "",
        color: "",
        expense: false,
      });
    }
  };

  const deleteCategory = async (id: string) => {
    await apiDeleteCategory(id);
    navigate("/categories");
  };

  const updateCategory = async (
    item: CategoryApiType,
    currentName?: string
  ) => {
    if (item && item.id && currentName) {
      const response = await apiUpdateCategory(item.id, item);

      navigate("/categories");
      if (response) {
        apiUpdateMany(currentName, item.title);
      }
      navigate("/categories");
    }
  };

  const selectStatus = (option: string) => {
    if (option === "DESPESAS") {
      setNewCategory((event) => ({ ...event, expense: true }));
    } else {
      setNewCategory((event) => ({ ...event, expense: false }));
    }
  };

  const selectColor = (option: string) => {
    setNewCategory((event) => ({ ...event, color: option }));
  };

  // const onConfirm = async (id: string, confirm: boolean) => {};

  return (
    <section className="container w-full flex flex-col mx-auto my-20 gap-2 p-2">
      <div className=" text-2xl">SUAS CATEGORIAS</div>
      {/* <Toast text={errors ?? undefined} /> */}
      <G_Alert alert={errors ?? undefined} />
      <div className="w-full flex flex-col lg:flex-row gap-2 mb-4 bg-gray-900">
        <G_InputArea
          type="text"
          placeholder="Nome da Categoria"
          onChange={handleChange}
          value={newCategory.title}
        />

        <div className="flex w-full gap-2">
          <G_Select
            onSelect={selectColor}
            optionList={tableColors}
            type="Colors"
            value={newCategory.color}
            className="w-full"
          />
          <G_Select
            onSelect={selectStatus}
            optionList={status}
            className="w-full"
          />

          <G_Button
            onClick={handleCreate}
            className="bg-blue-900 flex justify-center w-full"
          >
            CRIAR
          </G_Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row w-full justify-between items-start gap-2">
        <div className="bg-appSecondaryColor min-h-52 w-full">
          <h1 className="flex items-center text-2xl gap-2 text-green-600 font-semibold p-3">
            <Icon icon="pepicons-print:triangle-down" /> RECEITAS
          </h1>
          {categoriesArray
            .filter((item) => !item.expense)
            .map((category, index) => (
              <div key={index} className="flex gap-2 w-full my-1">
                <EditedInput
                  category={category}
                  onDelete={deleteCategory}
                  onUpdate={updateCategory}
                />
              </div>
            ))}
        </div>

        <div className="bg-appSecondaryColor min-h-52 w-full">
          <h1 className="flex items-center text-2xl gap-2 text-red-600 font-semibold p-3">
            <Icon icon="pepicons-print:triangle-down" /> DESPESAS
          </h1>
          {categoriesArray
            .filter((item) => item.expense)
            .map((category, index) => (
              <div key={index} className="flex gap-2 w-full my-1">
                <EditedInput
                  category={category}
                  onDelete={deleteCategory}
                  onUpdate={updateCategory}
                />
              </div>
            ))}
        </div>
      </div>
      {/* <G_Confirm
        description="Deseja deletar a categoria?"
        onConfirm={onConfirm}
        isOpen={isAlertOpen}
        onClose={() => setIsAlertOpen(false)}
      /> */}
    </section>
  );
};

export default Categories;
