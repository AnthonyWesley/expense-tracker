import { useState, useEffect } from "react";
import G_Button from "./G_Button";

export type ErrorObject = {
  message?: string | undefined;
  type?: "warning" | "error" | "success" | undefined;
};

export type G_AlertType = {
  alert: ErrorObject;
};

export const G_Alert = ({ alert }: G_AlertType) => {
  const [showToast, setShowToast] = useState(false);
  const [showAlert, setShowAlert] = useState(true);
  const [position, setPosition] = useState(0);
  const [errors, setErrors] = useState<ErrorObject | string>({});

  useEffect(() => {
    if (alert?.message) {
      setShowToast(true);

      const timeoutId = setTimeout(() => {
        setShowToast(false);
        setPosition(0);
      }, 3000);
      setErrors({});

      // const timeoutId2 = setTimeout(() => {
      //   setShowAlert(false);
      //   // setShowToast(false);
      //   // setPosition(0);
      //   // setErrors({});
      // }, 3000);

      setErrors(alert.message);

      return () => {
        clearTimeout(timeoutId);
        // clearTimeout(timeoutId2);
      };
    }
  }, [alert.message]);

  return (
    <div
      className={`${
        showToast ? "-translate-x-0" : "translate-x-[500%]"
      }  fixed right-0 top-0 z-40 flex h-screen flex-col items-start justify-start bg-transparent transition-transform duration-300 ease-in-out`}
    >
      {alert.message &&
        Object?.entries(errors).map(([key, value]) => (
          <div
            style={{
              top: `${position}px`,
              backgroundColor:
                alert.type === "error"
                  ? "red"
                  : alert.type === "success"
                  ? "green"
                  : "orange",
            }}
            key={key}
            className="w-full flex justify-between items-start text-lg md:text-xl lg:text-2xl rounded-md p-2 my-2"
          >
            <div className="p-3 text-sm">{value.toUpperCase()}</div>

            <G_Button className="text-sm" onClick={() => setShowToast(false)}>
              X
            </G_Button>
          </div>
        ))}
    </div>
  );
};
