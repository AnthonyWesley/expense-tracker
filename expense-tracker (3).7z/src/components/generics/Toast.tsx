import { useState, useEffect } from "react";
import G_Button from "./G_Button";

export type ErrorObject = {
  errorValue?: string;
  errorDescription?: string;
  errorDate?: string;
  errorCategory?: string;
};

export const Toast = ({ text }: { text: ErrorObject | undefined }) => {
  const [showToast, setShowToast] = useState(false);
  const [position, setPosition] = useState(0);
  const [errors, setErrors] = useState<ErrorObject>({});

  useEffect(() => {
    if (text) {
      setShowToast(true);

      const timeoutId = setTimeout(() => {
        setShowToast(false);
        setPosition(0);
        setErrors({});
      }, 3000);

      setErrors(text);

      return () => {
        clearTimeout(timeoutId);
      };
    }
  }, [text]);

  return (
    <div>
      {showToast && (
        <div
          style={{ top: `${position}px` }}
          className="absolute z-50 right-0 text-white "
        >
          {Object.entries(errors).map(([key, value]) => (
            <div
              key={key}
              className="flex justify-between items-start text-lg md:text-xl lg:text-2xl bg-red-700 rounded-md p-2 my-2"
            >
              <div className="p-2 text-sm my-2">{value}</div>
              <G_Button className="text-sm" onClick={() => setShowToast(false)}>
                X
              </G_Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
